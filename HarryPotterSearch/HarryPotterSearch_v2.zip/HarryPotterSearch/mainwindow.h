#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>  // 必须包含
#include <QString>      // Qt 字符串类
#include <vector>       // std::vector
#include <array>        // std::array

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();
    void on_textBrowser_anchorClicked(const QUrl &url);

private:
    Ui::MainWindow *ui;
    struct SearchInfo {
        int bookIndex;
        int pageNumber;
        int chapterNumber;
        QString lineContent;
        SearchInfo(int bookIndex, int pageNumber, int chapterNumber, const QString& line)
            : bookIndex(bookIndex), pageNumber(pageNumber), chapterNumber(chapterNumber), lineContent(line) {}
        QString getLine() const { return lineContent; }
    };

    std::vector<SearchInfo> searchResults_;
    const std::array<QString, 8> bookFiles_ = {
        "Quidditch_Through_the_Ages.txt",
        "HP6_Harry_Potter_and_the_Half_Blood_Prince.txt",
        "HP4_Harry_Potter_and_the_Goblet_of_Fire.txt",
        "HP3_Harry_Potter_and_the_Prisoner_of_Azkaban.txt",
        "HP0_Harry_Potter_Prequel.txt",
        "HP7_Harry_Potter_and_the_Deathly_Hallows_Book_7.txt",
        "HP2_Harry_Potter_and_the_Chamber_of_Secrets_Book_2.txt",
        "The_Tales_of_Beedle_the_Bard.txt"
    };

    bool isChapterHeader(const QString &line);
    bool isPageNumber(const QString &line);
};

#endif // MAINWINDOW_H
