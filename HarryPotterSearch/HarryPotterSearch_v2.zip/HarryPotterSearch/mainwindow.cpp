#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFile>         // 文件操作
#include <QTextStream>   // 文本流
#include <QMessageBox>   // 消息框
#include <QUrl>          // URL 处理
#include <QDebug>       // 日志输出

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->textBrowser->setOpenExternalLinks(false);
    ui->textBrowser->setOpenLinks(false);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    searchResults_.clear();
    ui->textBrowser->clear();

    QString searchText = ui->lineEdit->text().trimmed();
    if (searchText.isEmpty()) return;

    int resultCount = 0;
    for (int i = 0; i < int(bookFiles_.size()); ++i) {
        QFile file(bookFiles_[i]);
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
            qWarning() << "Failed to open file:" << bookFiles_[i];
            continue;
        }

        QTextStream in(&file);
        int currentPage = 0;
        int currentChapter = 0;
        while (!in.atEnd()) {
            QString line = in.readLine().trimmed();
            if (line.isEmpty()) continue;

            if (isChapterHeader(line)) {
                currentChapter++;
                continue;
            }

            if (isPageNumber(line)) {
                currentPage = line.toInt();
                continue;
            }

            if (line.contains(searchText, Qt::CaseInsensitive)) {
                searchResults_.emplace_back(i, currentPage, currentChapter, line);
                resultCount++;
                ui->textBrowser->append(QString("<a href='item:%1'>%1</a> &nbsp;&nbsp; %2 &nbsp;&nbsp; Page %3 &nbsp;&nbsp; Chapter %4 &nbsp;&nbsp; %5")
                                            .arg(resultCount)
                                            .arg(searchText)
                                            .arg(currentPage)
                                            .arg(currentChapter)
                                            .arg(bookFiles_[i]));
            }
        }
        file.close();
    }
}

bool MainWindow::isChapterHeader(const QString &line)
{
    return line.startsWith("CHAPTER", Qt::CaseInsensitive)
    || line.startsWith("Chapter", Qt::CaseInsensitive);
}

bool MainWindow::isPageNumber(const QString &line)
{
    bool ok;
    int num = line.toInt(&ok);
    return ok && num > 0 && line == QString::number(num);
}

void MainWindow::on_pushButton_2_clicked()
{
    bool ok;
    int input = ui->lineEdit_2->text().toInt(&ok);
    if (!ok || input < 1 || input > int(searchResults_.size())) {
        QMessageBox::warning(this, "Error", "Invalid entry number");
        return;
    }

    ui->textBrowser_2->setText(searchResults_[input - 1].getLine());
}

void MainWindow::on_textBrowser_anchorClicked(const QUrl &url)
{
    if (url.scheme() == "item") {
        bool ok;
        int index = url.path().toInt(&ok);
        if (ok && index >= 1 && index <= int(searchResults_.size())) {
            ui->textBrowser_2->setText(searchResults_[index - 1].getLine());
        }
    }
}
